package io.aridhiran.conceptnet

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

private val Navy = Color(0xFF102B4E)
private val Blue = Color(0xFF1769D2)
private val Pale = Color(0xFFEAF2FF)
private val Ink = Color(0xFF202938)
private val Muted = Color(0xFF657184)

data class Edge(
    val relation: String,
    val start: String,
    val end: String,
    val startLabel: String,
    val endLabel: String,
    val weight: Double
)

data class ConceptResult(
    val term: String,
    val language: String,
    val edges: List<Edge>,
    val related: List<String>
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ConceptNetApp(this) }
    }
}

private fun nodeLabel(uri: String): String {
    val part = uri.substringAfterLast("/")
    return part.replace('_', ' ').replaceFirstChar { it.uppercase() }
}

private fun fetchJson(path: String): JSONObject {
    val url = URL("https://api.conceptnet.io$path")
    val connection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 15000
        readTimeout = 20000
        setRequestProperty("Accept", "application/ld+json")
        setRequestProperty("User-Agent", "ConceptNetAndroid/1.0")
    }
    return try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw Exception("ConceptNet returned HTTP $code")
        JSONObject(body)
    } finally {
        connection.disconnect()
    }
}

private suspend fun searchConcept(term: String, language: String): ConceptResult =
    withContext(Dispatchers.IO) {
        val slug = URLEncoder.encode(term.trim().replace(' ', '_'), "UTF-8")
        val lang = language.trim().ifBlank { "en" }
        val node = "/c/$lang/$slug"
        val conceptJson = fetchJson("$node?limit=50&offset=0&format=json")
        val edgesJson = conceptJson.optJSONArray("edges")
        val edges = mutableListOf<Edge>()
        if (edgesJson != null) {
            for (i in 0 until edgesJson.length()) {
                val item = edgesJson.optJSONObject(i) ?: continue
                val rel = item.optJSONObject("rel") ?: JSONObject()
                val start = item.optJSONObject("start") ?: JSONObject()
                val end = item.optJSONObject("end") ?: JSONObject()
                val startUri = start.optString("@id")
                val endUri = end.optString("@id")
                edges.add(
                    Edge(
                        relation = rel.optString("label", rel.optString("@id").substringAfterLast("/")),
                        start = startUri,
                        end = endUri,
                        startLabel = start.optString("label", nodeLabel(startUri)),
                        endLabel = end.optString("label", nodeLabel(endUri)),
                        weight = item.optJSONObject("weight")?.optDouble("value", 1.0) ?: item.optDouble("weight", 1.0)
                    )
                )
            }
        }
        val relatedJson = runCatching {
            fetchJson("/related/c/$lang/$slug?limit=20&format=json")
        }.getOrNull()
        val relatedArray = relatedJson?.optJSONArray("related")
        val related = mutableListOf<String>()
        if (relatedArray != null) {
            for (i in 0 until relatedArray.length()) {
                val item = relatedArray.optJSONObject(i) ?: continue
                val label = item.optString("label", nodeLabel(item.optString("@id")))
                if (label.isNotBlank() && !label.equals(term, true)) related.add(label)
            }
        }
        ConceptResult(term, lang, edges, related.distinct())
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConceptNetApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("conceptnet", Context.MODE_PRIVATE) }
    var query by remember { mutableStateOf("") }
    var language by remember { mutableStateOf("en") }
    var selectedTab by remember { mutableIntStateOf(0) }
    var result by remember { mutableStateOf<ConceptResult?>(null) }
    var saved by remember { mutableStateOf(prefs.getStringSet("saved", emptySet())?.toSet() ?: emptySet()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun runSearch(term: String) {
        if (term.isBlank()) return
        query = term
        loading = true
        error = null
        selectedTab = 0
        scope.launch {
            try {
                result = searchConcept(term, language)
            } catch (e: Exception) {
                error = e.message ?: "Unable to reach ConceptNet. Check your connection."
            } finally {
                loading = false
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue, onPrimary = Color.White, background = Color(0xFFF8FAFD),
            surface = Color.White, onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFF8FAFD),
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selectedTab == 0, { selectedTab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selectedTab == 1, { selectedTab = 1 }, icon = { Icon(Icons.Default.AccountTree, null) }, label = { Text("Explore") })
                    NavigationBarItem(selectedTab == 2, { selectedTab = 2 }, icon = { Icon(Icons.Default.BookmarkBorder, null) }, label = { Text("Saved") })
                    NavigationBarItem(selectedTab == 3, { selectedTab = 3 }, icon = { Icon(Icons.Default.Info, null) }, label = { Text("About") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (selectedTab) {
                    0 -> HomeScreen(
                        query, { query = it }, language, { language = it },
                        loading, error, result, saved,
                        { runSearch(it) }, { runSearch(it) },
                        { term -> saved = saved + term; prefs.edit().putStringSet("saved", saved).apply() },
                        { term -> saved = saved - term; prefs.edit().putStringSet("saved", saved).apply() }
                    )
                    1 -> ExploreScreen(result, { runSearch(it) })
                    2 -> SavedScreen(saved, { runSearch(it); selectedTab = 0 }, { term ->
                        saved = saved - term
                        prefs.edit().putStringSet("saved", saved).apply()
                    })
                    else -> AboutScreen()
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    query: String, onQuery: (String) -> Unit,
    language: String, onLanguage: (String) -> Unit,
    loading: Boolean, error: String?, result: ConceptResult?, saved: Set<String>,
    search: (String) -> Unit, example: (String) -> Unit,
    save: (String) -> Unit, unsave: (String) -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            GraphMark(54)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("ConceptNet", fontSize = 29.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("Explore commonsense knowledge", fontSize = 13.sp, color = Muted)
            }
            Icon(Icons.Default.MoreVert, null, tint = Muted)
        }
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = query, onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search for a concept...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { onQuery("") }) { Icon(Icons.Default.Close, null) }
            },
            shape = RoundedCornerShape(18.dp), singleLine = true
        )
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Language code", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(
                value = language, onValueChange = { onLanguage(it.take(3)) },
                modifier = Modifier.width(90.dp).height(54.dp),
                singleLine = true, textStyle = LocalTextStyle.current.copy(fontSize = 14.sp)
            )
            Spacer(Modifier.weight(1f))
            Button(onClick = { search(query) }, enabled = query.isNotBlank() && !loading) {
                if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                else Text("Search")
            }
        }
        Spacer(Modifier.height(20.dp))
        Surface(color = Pale, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Try these examples", fontWeight = FontWeight.SemiBold, color = Navy)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("dog", "book", "music").forEach {
                        SuggestionChip(onClick = { example(it) }, label = { Text(it) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("travel", "science").forEach {
                        SuggestionChip(onClick = { example(it) }, label = { Text(it) })
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        if (error != null) {
            Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
        }
        if (result != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Results for ${result.term}", fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { if (saved.contains(result.term)) unsave(result.term) else save(result.term) }) {
                    Icon(if (saved.contains(result.term)) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null)
                    Text(if (saved.contains(result.term)) "Saved" else "Save")
                }
            }
            Text("${result.edges.size} relationships · ${result.related.size} related concepts", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            if (result.related.isNotEmpty()) {
                Text("Related concepts", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                result.related.take(12).forEach { item ->
                    Row(
                        Modifier.fillMaxWidth().clickable { search(item) }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        GraphMark(28)
                        Spacer(Modifier.width(12.dp))
                        Text(item, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                    }
                    HorizontalDivider(color = Color(0xFFE9EDF3))
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Relationships", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            result.edges.take(30).forEach { edge ->
                EdgeCard(edge)
            }
        } else {
            Text("Related Concepts", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("Search a word or phrase to explore its connections in the ConceptNet knowledge graph.", color = Muted, modifier = Modifier.padding(top = 8.dp))
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun EdgeCard(edge: Edge) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(13.dp)) {
            Text(edge.relation.replaceFirstChar { it.uppercase() }, color = Blue, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text("${edge.startLabel}  →  ${edge.endLabel}", fontWeight = FontWeight.Medium, color = Ink)
            Text("Weight: ${"%.2f".format(edge.weight)}", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ExploreScreen(result: ConceptResult?, search: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Explore graph", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("A simplified view of the current concept and its related terms.", color = Muted)
        Spacer(Modifier.height(20.dp))
        if (result == null) {
            Text("Search for a concept on the Home tab to build a graph.")
        } else {
            GraphView(result.term, result.related.take(10))
            Spacer(Modifier.height(20.dp))
            result.related.forEach { term ->
                ListItem(
                    headlineContent = { Text(term) },
                    leadingContent = { GraphMark(28) },
                    trailingContent = { Icon(Icons.Default.ChevronRight, null) },
                    modifier = Modifier.clickable { search(term) }
                )
            }
        }
    }
}

@Composable
private fun GraphView(center: String, nodes: List<String>) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(Modifier.fillMaxWidth().height(250.dp)) {
                val c = Offset(size.width / 2f, size.height / 2f)
                val radius = size.minDimension * 0.37f
                val pts = nodes.mapIndexed { i, _ ->
                    val a = (2.0 * Math.PI * i / maxOf(nodes.size, 1)) - Math.PI / 2
                    Offset(c.x + radius * kotlin.math.cos(a).toFloat(), c.y + radius * kotlin.math.sin(a).toFloat())
                }
                pts.forEach { drawLine(Color(0xFF9CB4D4), c, it, strokeWidth = 3f) }
                pts.forEach { drawCircle(Blue, 10f, it) }
                drawCircle(Navy, 17f, c)
            }
            Text(center, color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Connected concepts", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SavedScreen(saved: Set<String>, open: (String) -> Unit, remove: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Saved concepts", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(12.dp))
        if (saved.isEmpty()) Text("No saved concepts yet. Save a concept from its search results.", color = Muted)
        LazyColumn {
            items(saved.toList().sorted()) { term ->
                ListItem(
                    headlineContent = { Text(term) },
                    leadingContent = { Icon(Icons.Default.Bookmark, null, tint = Blue) },
                    modifier = Modifier.clickable { open(term) },
                    trailingContent = {
                        IconButton(onClick = { remove(term) }) { Icon(Icons.Default.DeleteOutline, null) }
                    }
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun AboutScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("About ConceptNet", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(12.dp))
        Text("ConceptNet is a multilingual commonsense knowledge graph. This app queries its public read-only API and displays concepts, relationships, and semantically related terms.")
        Spacer(Modifier.height(16.dp))
        Text("Data source", fontWeight = FontWeight.Bold)
        Text("ConceptNet 5 · api.conceptnet.io")
        Spacer(Modifier.height(12.dp))
        Text("API usage", fontWeight = FontWeight.Bold)
        Text("Search requests require an internet connection. Saved concept names are stored locally on this device.")
        Spacer(Modifier.height(12.dp))
        Text("License", fontWeight = FontWeight.Bold)
        Text("ConceptNet data is available under the Creative Commons Attribution-ShareAlike 4.0 International License. See the official documentation for attribution requirements.")
    }
}

@Composable
private fun GraphMark(dimension: Int) {
    Canvas(Modifier.size(dimension.dp)) {
        val p = listOf(
            Offset(size.width * .18f, size.height * .25f),
            Offset(size.width * .72f, size.height * .12f),
            Offset(size.width * .82f, size.height * .75f),
            Offset(size.width * .30f, size.height * .82f),
            Offset(size.width * .48f, size.height * .48f)
        )
        listOf(0 to 4, 1 to 4, 2 to 4, 3 to 4, 0 to 3, 1 to 2).forEach {
            drawLine(Color(0xFF8DA4C2), p[it.first], p[it.second], 2.2f)
        }
        p.forEachIndexed { i, pt ->
            drawCircle(if (i % 2 == 0) Blue else Color(0xFF8295AC), size.minDimension * if (i == 4) .13f else .17f, pt)
        }
    }
}
