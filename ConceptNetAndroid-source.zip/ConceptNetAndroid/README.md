# ConceptNet Android

A native Kotlin + Jetpack Compose Android client for the public ConceptNet API.

## Features
- Live ConceptNet concept lookup
- Relationship edges with relation labels and weights
- Numberbatch-related concepts
- Simple connected-concept graph view
- Local saved-concept list
- Language-code input (for example `en`, `ta`, `fr`, `ja`)

## API
Uses the public read-only API at `https://api.conceptnet.io`.
No API key is required. Requests are made over HTTPS.

## Build in Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder as an existing Gradle project.
3. Use JDK 17.
4. Wait for Gradle sync.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Build with GitHub Actions
1. Create an empty GitHub repository.
2. Upload/push this project to the repository's `main` branch.
3. Open **Actions > Build Android APK > Run workflow** (or push to `main`).
4. Download the `ConceptNet-debug-apk` artifact from the completed workflow.

## Notes
- Internet access is required for live API searches.
- Saved concept names are stored locally using Android SharedPreferences.
- This is a debug APK build configuration. A release APK should be signed with your own signing key before distribution.
- ConceptNet data is licensed under CC BY-SA 4.0. Retain appropriate attribution when redistributing data or derived content.
